//
//  LoginVC.swift
//  TestingApp
//
//  Created by Michael Mitchual on 5/23/17.
//  Copyright © 2017 Michael Mitchual. All rights reserved.
//

import UIKit

class LoginVC: UIViewController {
    
    // declare UI object
    @IBOutlet weak var usernameTxt: UITextField!
    @IBOutlet weak var passwordTxt: UITextField!

    // first function that is loaded
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    // clicked login button
    @IBAction func login_click(_ sender: Any) {
        
        // no text entered
        if usernameTxt.text!.isEmpty || passwordTxt.text!.isEmpty {
          
            // red placeholders
            usernameTxt.attributedPlaceholder = NSAttributedString(string: "username", attributes: [NSAttributedStringKey.foregroundColor: UIColor.red])
            passwordTxt.attributedPlaceholder = NSAttributedString(string: "password", attributes: [NSAttributedStringKey.foregroundColor: UIColor.red])
        } else {

            // remove keyboard
            self.view.endEditing(true)
            
            let url = NSURL(string: "http://circleapp.pairserver.com/login.php")!
            let request = NSMutableURLRequest(url: url as URL)
            request.httpMethod = "POST"
            print("Request: \(request)")
            
            // Body for the request
            let body = "username=\(usernameTxt.text!)&password=\(passwordTxt.text!)"
            
            request.httpBody = body.data(using: String.Encoding.utf8)
            
            print("Request: \(request)")
            
            print("RequestBody: \(String(describing: request.httpBody))")
            
            // launch session
            URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { (data:Data?, response: URLResponse?, error:Error?) in
                
                if (error == nil) {
                    
                        do {

                            let json  = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                            
                            guard let parseJSON = json else {
                                print ("Error while parsing JSON")
                                return
                            }
                            
                            print(parseJSON)
                            
                            // Get the ID from the JSON struct
                            let id = parseJSON["id"] as? String
                            
                            // successfully logged in
                            if (id != nil) {
                                
                                // save user information we received from our host 
                                UserDefaults.standard.set(parseJSON, forKey: "parseJSON")
                                user = UserDefaults.standard.value(forKey: "parseJSON") as? NSDictionary
                                
                                // go to tabbar or homepage
                                DispatchQueue.main.async {
                                    appDelegate.login()
                                }
                                
                                
                            
                            } else {
                                
                                // get main queue to communicate back to user
                                DispatchQueue.main.async(execute: {
                                    let message = parseJSON["message"] as! String
                                    appDelegate.infoView(message: message, color: colorSmoothRed)
                                })
                                return
                                
                            }
                    
                            
                        } catch {
                            DispatchQueue.main.async(execute: {
                                let message = error as! String
                                appDelegate.infoView(message: message, color: colorSmoothRed)
                            })
                            return
                        }
                        

                    } else {
                    
                    print("Error: \(String(describing: error))")
                    
                    // get main queue to communicate back to user
                    DispatchQueue.main.async(execute: {
                        let message = error!.localizedDescription
                        appDelegate.infoView(message: message, color: colorSmoothRed)
                    })
                }
                
                // launch prepared session
                
            }).resume()

        }
    }
    
    // white status bar
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return UIStatusBarStyle.lightContent
    }

    // touched screen
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        // hide keyboard
        self.view.endEditing(false)
    }


}
