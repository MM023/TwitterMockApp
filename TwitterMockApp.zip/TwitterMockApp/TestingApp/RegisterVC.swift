//
//  ViewController.swift
//  TestingApp
//
//  Created by Michael Mitchual on 5/15/17.
//  Copyright © 2017 Michael Mitchual. All rights reserved.
//

import UIKit

class RegisterVC: UIViewController {
    
    // declare UI objects
    @IBOutlet weak var usernameTxt: UITextField!
    @IBOutlet weak var passwordTxt: UITextField!
    @IBOutlet weak var emailTxt: UITextField!
    @IBOutlet weak var firstnameTxt: UITextField!
    @IBOutlet weak var lastnameTxt: UITextField!
    @IBOutlet weak var usernameLbl: UILabel!
    @IBOutlet weak var emailLbl: UILabel!
    
    @IBOutlet weak var registerBtn: UIButton!
    
    // first function that is loaded
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.  
        
    }
    
    
    // Check if username is already in the database
    @IBAction func TextFieldEditingDidChange(_ sender: Any) {
        let request = NSMutableURLRequest(url: NSURL(string: "http://circleapp.pairserver.com/usernamecheck.php")! as URL)
        request.httpMethod = "POST"
        print("Request: \(request)")
        let postString = "username=\(usernameTxt.text!)"
        request.httpBody = postString.data(using: String.Encoding.utf8)
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            if error != nil {
                print("error=\(String(describing: error))")
                return
            } // Ends error If statements
            print("response = \(String(describing: response))")
             let responseString = String(data: data!, encoding: .utf8) ?? "Non-UTF8 data received"
            DispatchQueue.main.async {
                print ("responseString = \(String(describing: responseString))")
                
                self.usernameLbl.text = ("\(String(describing: responseString))")
                
                
            }
           
        } // Ends let task
        task.resume()
        
    }
    
    // Check if email is already in the database 
    @IBAction func Email(_ sender: Any) {
        
        let request = NSMutableURLRequest(url: NSURL(string: "http://circleapp.pairserver.com/emailcheck.php")! as URL)
        request.httpMethod = "POST"
        print("Request: \(request)")
        let postString = "email=\(emailTxt.text!)"
        request.httpBody = postString.data(using: String.Encoding.utf8)
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            if error != nil {
                print("error=\(String(describing: error))")
                return
            } // Ends error If statements
            print("response = \(String(describing: response))")
            let responseString = String(data: data!, encoding: .utf8) ?? "Non-UTF8 data received"
            DispatchQueue.main.async {
                print ("responseString = \(String(describing: responseString))")
                
                self.emailLbl.text = ("\(String(describing: responseString))")
                
                
            }
            
        } // Ends let task
        task.resume()
        
    }

    
  
    
    // register button clicked
    @IBAction func register_click(_ sender: Any) {
        
        // if no text
        if usernameTxt.text!.isEmpty || passwordTxt.text!.isEmpty || emailTxt.text!.isEmpty || firstnameTxt.text!.isEmpty || lastnameTxt.text!.isEmpty {
         
            // red placeholders 
            usernameTxt.attributedPlaceholder = NSAttributedString(string: "Username", attributes: [NSAttributedStringKey.foregroundColor: UIColor.red])
            passwordTxt.attributedPlaceholder = NSAttributedString(string: "Password", attributes: [NSAttributedStringKey.foregroundColor: UIColor.red])
            emailTxt.attributedPlaceholder = NSAttributedString(string: "Email", attributes: [NSAttributedStringKey.foregroundColor: UIColor.red])
            firstnameTxt.attributedPlaceholder = NSAttributedString(string: "First name", attributes: [NSAttributedStringKey.foregroundColor: UIColor.red])
            lastnameTxt.attributedPlaceholder = NSAttributedString(string: "Last name", attributes: [NSAttributedStringKey.foregroundColor: UIColor.red])
       
        } else {
            
            // remove keyboard
            self.view.endEditing(true)
            
            
            let url = NSURL(string: "http://circleapp.pairserver.com/register.php")!
            let request = NSMutableURLRequest(url: url as URL)
            request.httpMethod = "POST"
            print("Request: \(request)")
            
            // Body for the request
            let body = "username=\(usernameTxt.text!.lowercased())&password=\(passwordTxt.text!.lowercased())&email=\(emailTxt.text!.lowercased())&fullname=\(firstnameTxt.text!.lowercased())%20\(lastnameTxt.text!.lowercased())"
            
            request.httpBody = body.data(using: String.Encoding.utf8)
            print("Request: \(request)")
            print("RequestBody: \(String(describing: request.httpBody))")
            
            URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { (data:Data?, response: URLResponse?, error:Error?) in
                
                if (error == nil) {
                    
                    // send the request to the server
                    print("Going to send the request to the server")
                    
                    // communicate back to UI
                    DispatchQueue.main.async(execute: {
                        
                        do {
                            
                            let json  = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                            
                            guard let parseJSON = json else {
                                print ("Error while parsing JSON")
                                return
                                
                            }
                            
                            // Get the ID from the JSON struct
                            let id = parseJSON["id"]
                            // if there is an ID then print the JSON
                            
                            if (id != nil) {
                                
                                // save user information we received from our host
                                UserDefaults.standard.set(parseJSON, forKey: "parseJSON")
                                user = UserDefaults.standard.value(forKey: "parseJSON") as? NSDictionary
                                
                                // go to tabbar or homepage
                                DispatchQueue.main.async {
                                    appDelegate.login()
                                }

                            } else {
                                
                                // get main queue to communicate back to user
                                DispatchQueue.main.async(execute: {
                                    let message = parseJSON["message"] as! String
                                    appDelegate.infoView(message: message, color: colorSmoothRed)
                                })

                                
                            }
                        } catch {
                            DispatchQueue.main.async(execute: {
                                let message = error as! String
                                appDelegate.infoView(message: message, color: colorSmoothRed)
                            })

                        }
                    } )
                } else {
                    // get main queue to communicate back to user
                    DispatchQueue.main.async(execute: {
                        let message = error!.localizedDescription
                        appDelegate.infoView(message: message, color: colorSmoothRed)
                    })

                }
                // launch prepared session
            }).resume()
        }
        
        // white status bar
        func preferredStatusBarStyle() -> UIStatusBarStyle {
            return UIStatusBarStyle.lightContent
        }
    }
        
    // touched screen
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        // hide keyboard
        self.view.endEditing(false)
    }



}
