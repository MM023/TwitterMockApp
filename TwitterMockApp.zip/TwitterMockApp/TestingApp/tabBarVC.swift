//
//  tabBarVC.swift
//  TestingApp
//
//  Created by Michael Mitchual on 5/28/17.
//  Copyright © 2017 Michael Mitchual. All rights reserved.
//

import UIKit

class tabBarVC: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // gray color of tabbar items
         let color = colorSmoothGray
        
        // color of item in tabbar controller 
        self.tabBar.tintColor = .white
        
        // color of background if tabbar controller 
        self.tabBar.barTintColor = colorBrandBlue
        
        // disable translucent 
        self.tabBar.isTranslucent = false 

        // color of text under icon in tabbar controller
        UITabBarItem.appearance().setTitleTextAttributes([NSAttributedStringKey.foregroundColor : colorSmoothGray], for: UIControlState())
        UITabBarItem.appearance().setTitleTextAttributes([NSAttributedStringKey.foregroundColor : UIColor.white], for: .selected)
        
        // new color for all icons of tabbar controller 
        for item in self.tabBar.items! as [UITabBarItem] {
         
            
            if let image = item.image {
               
                item.image = image.imageColor(color).withRenderingMode(.alwaysOriginal)
         
            }
            
        }
    }
    
}

    // new class we created to refer to our icon in tabbar controller.
    extension UIImage {
        
        // in this func we customize our UIImage - our icon
        @objc func imageColor(_ color : UIColor) -> UIImage {
            
            UIGraphicsBeginImageContextWithOptions(self.size, false, self.scale)
            
            let context = UIGraphicsGetCurrentContext()! as CGContext
            context.translateBy(x: 0, y: self.size.height)
            context.scaleBy(x: 1.0, y: -1.0)
            
            let rect = CGRect(x: 0, y: 0, width: self.size.width, height: self.size.height) as CGRect
            context.clip(to: rect, mask: self.cgImage!)
            
            color.setFill()
            context.fill(rect)
            
            let newImage = UIGraphicsGetImageFromCurrentImageContext()!
            UIGraphicsEndImageContext()
            
            return newImage
        }
        


 
}
