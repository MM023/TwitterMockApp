//
//  UsersCell.swift
//  TestingApp
//
//  Created by Michael Mitchual on 6/3/17.
//  Copyright © 2017 Michael Mitchual. All rights reserved.
//

import UIKit

class UsersCell: UITableViewCell {
    
    // delcare UI objects
    @IBOutlet weak var avaImg: UIImageView!
    @IBOutlet weak var usernameLbl: UILabel!
    @IBOutlet weak var fullnameLbl: UILabel!

    // fist function that is loaded
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code 
        
        // round corners on the profile picture
        avaImg.layer.cornerRadius = avaImg.bounds.width / 2
        avaImg.clipsToBounds = true
        
        // change the text color of the username label
        usernameLbl.textColor = colorBrandBlue
        
        
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
