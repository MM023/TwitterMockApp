//
//  UsersVC.swift
//  TestingApp
//
//  Created by Michael Mitchual on 6/3/17.
//  Copyright © 2017 Michael Mitchual. All rights reserved.
//

import UIKit

class UsersVC: UITableViewController, UISearchBarDelegate {
    
    // delcare UI objects
    @IBOutlet weak var searchBar: UISearchBar!
    
    // array of objects to store all user information
    @objc var users = [AnyObject]()
    @objc var avas = [UIImage]()
    
    // first function that is loaded
    override func viewDidLoad() {
        super.viewDidLoad()

        // search bar customization 
        searchBar.barTintColor = .white // search bar color
        searchBar.tintColor = colorBrandBlue // elements of searchbar
        searchBar.showsCancelButton = false

        // call function to find users
        doSearch("")
        
    }
    
    // once text is entered in search bar
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        // search php request 
        doSearch(searchBar.text!)
    }

    // did begin editing of text in search bar
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.showsCancelButton = true
    }
  
    // clicked cancel on search bar
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        
        searchBar.endEditing(false) // removes keyboard 
        searchBar.showsCancelButton = false
        searchBar.text = ""
        
        // clean up
        users.removeAll(keepingCapacity: false)
        avas.removeAll(keepingCapacity: false)
        tableView.reloadData()
        
         doSearch("")
        
        
    }
    // cell number
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return users.count
        
        
    }

    // cell configuration
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! UsersCell

        // get one by one user related inf from users var
        let user = users[indexPath.row]
        let ava = avas[indexPath.row]
        
        // shortcuts
        let username = user["username"] as? String
        let fullname = user["fullname"] as? String
        
        // refer str to cell obj
        cell.usernameLbl.text = username
        cell.fullnameLbl.text = fullname
        cell.avaImg.image = ava
        
        return cell
    }
    
    // search or retrieve users
    @objc func doSearch(_ word : String) {
        
        // shortucs
        let word = searchBar.text!.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        let username = user!["username"] as! String
        
        let url = URL(string: "http://circleapp.pairserver.com/users.php")!  // url path to users.php file
        let request = NSMutableURLRequest(url: url) // create request to work with users.php file
        request.httpMethod = "POST" // method of passing information to users.php
        let body = "word=\(word)&username=\(username)" // body that passes information to users.php
        request.httpBody = body.data(using: String.Encoding.utf8) // convert string to utf8 string to supports all languages
        
          // launch session
          URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { (data:Data?, response: URLResponse?, error:Error?) in
            
            // getting main queue of proceeding inf to communicate back, in another way it will do it in background
            // and user will no see changes :)
            DispatchQueue.main.async(execute: {
                
                if error == nil {
                    
                    do {
                       
                        // declare json variable to store $returnArray information returned from users.php file
                        let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                        
                        // clean up
                        self.users.removeAll(keepingCapacity: false)
                        self.avas.removeAll(keepingCapacity: false)
                        self.tableView.reloadData()
                        
                        // delcare new secure var to store json
                        guard let parseJSON = json else {
                            print("Error while parsing")
                            return
                        }
                        
                        // declare new secure variable to store $returnArray["users"]
                        guard let parseUSERS = parseJSON["users"] else {
                            print(parseJSON["message"]!)
                            return
                        }
                        
                        // append $returnArray["users"] to self.users var
                        self.users = parseUSERS as! [AnyObject]
                        
                        
                        // for i=0; i < users.count; i++
                        for i in 0 ..< self.users.count {
                            
                            // getting path to ava file of user
                            let ava = self.users[i]["ava"] as? String
                            
                            // if path exist, load ava via path
                            if !ava!.isEmpty {
                                let url = URL(string: ava!)! // convert parth of string to url
                                let imageData = try? Data(contentsOf: url) // get data via url and assing to imageData
                                let image = UIImage(data: imageData!)! // convert data of image via data imageData to UIImage
                                self.avas.append(image)
                                
                                // else use placeholder for ava
                            } else {
                                let image = UIImage(named: "ava.jpg")
                                self.avas.append(image!)
                            }
                            
                        }
                        
                        
                        self.tableView.reloadData()
                        
                        
                        
                    } catch {
                        
                        // get main queue to communicate back to user
                        DispatchQueue.main.async(execute: {
                            let message = String(describing: error)
                            appDelegate.infoView(message: message, color: colorSmoothRed)
                        })
                        return
                    }
                    
                    
                } else {
                    
                    // get main queue to communicate back to user
                    DispatchQueue.main.async(execute: {
                        let message = error!.localizedDescription
                        appDelegate.infoView(message: message, color: colorSmoothRed)
                    })
                    return
                }
                
            })
            
        }) .resume()
        
        
        
    }
    
    // proceeding segues that have been made in main.storyboard to another view controller
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        // declare cell that was clicked in tableview
        if let cell = sender as? UITableViewCell {
            
            // define index to later on pass exact guest user related information
            let index = tableView.indexPath(for: cell)!.row
            
            // if segue has an identifier of "guest"...
            if segue.identifier == "guest" {
                
                // call guestvc to access guest var
                let guestvc = segue.destination as! GuestVC
                
                // assign guest user information to guest variable
                guestvc.guest = users[index] as! NSDictionary
                
                // new back button
                let backItem = UIBarButtonItem()
                backItem.title = ""
                navigationItem.backBarButtonItem = backItem
                
            }
            
        }
        
    }


}

