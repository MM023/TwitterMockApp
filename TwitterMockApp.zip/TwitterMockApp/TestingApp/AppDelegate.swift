//
//  AppDelegate.swift
//  TestingApp
//
//  Created by Michael Mitchual on 5/15/17.
//  Copyright © 2017 Michael Mitchual. All rights reserved.
//

import UIKit

// global variable referred to appDeleagate to be able to call it from any class / file.swift 
let appDelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate

// declare colors
let colorSmoothRed = UIColor(red: 255/255, green: 50/255, blue: 75/255, alpha: 1)
let colorLightGreen = UIColor(red: 30/255, green: 244/255, blue: 125/255, alpha: 1)
let colorSmoothGray = UIColor(red: 230/255, green: 230/255, blue: 230/255, alpha: 1)
let colorBrandBlue = UIColor(red: 45 / 255, green: 213 / 255, blue: 255 / 255, alpha: 1)

// declare font size
let fontSize12 = UIScreen.main.bounds.width / 31

// stores all information about current user
var user : NSDictionary?


@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    
    // boolean to check if errorview is currently showing 
    @objc var infoViewIsShowing = false
    
    @objc func infoView(message:String, color:UIColor)  {
        
        // if errorView is not showing ...
        if infoViewIsShowing == false {
           
            // cast as errorView is currently showing
            infoViewIsShowing = true
            
            // red background 
            let infoView_Height = self.window!.bounds.height / 14.2
            let infoView_Y = 0 - infoView_Height
            
            
            let infoView = UIView(frame: CGRect(x: 0, y: infoView_Y, width: self.window!.bounds.width, height: infoView_Height))
            infoView.backgroundColor = color
            self.window!.addSubview(infoView)
            
            // error label to show the error text 
            let infoLabel_width = infoView.bounds.width
            let infoLabel_Height = infoView.bounds.height + UIApplication.shared.statusBarFrame.height / 2
            

            let infoLabel = UILabel()
            infoLabel.frame.size.width = infoLabel_width
            infoLabel.frame.size.height = infoLabel_Height
            infoLabel.numberOfLines = 0
            
            infoLabel.text = message
            infoLabel.font = UIFont(name: "HelveticaNeue", size: fontSize12)
            infoLabel.textColor = .white
            infoLabel.textAlignment = .center
            
            infoView.addSubview(infoLabel)
            
            // animate error view
            UIView.animate(withDuration: 0.2, animations: {
              infoView.frame.origin.y = 0
                
            // if animation did finish
            }, completion: { (finished:Bool) in
                
                // if it is true
                if finished {
                    
                    UIView.animate(withDuration: 0.1, delay: 3, options: .curveLinear, animations: {
                        
                        // move up infoView
                        infoView.frame.origin.y = infoView_Y
                        
                    // if finished all animations
                    }, completion: { (finished:Bool) in
                        
                        if finished {
                            infoView.removeFromSuperview()
                            infoLabel.removeFromSuperview()
                            self.infoViewIsShowing = false
                        }
                        
                    })
                    
                }
                
            })
            
            
        }
        
    }
    
    // function to pass to home page or to tabBar
    @objc func login() {
        
        // refer to our Main.Storyboard
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        
        // Store our tabBar Object from Main.Storyboard in tabBar variable
        let taBar = storyBoard.instantiateViewController(withIdentifier: "tabBar")
        
        // Present tabBar that is storing in tabBar variable
        window?.rootViewController = taBar
        
    }
    


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        // load content in user var 
        user = UserDefaults.standard.value(forKey: "parseJSON") as? NSDictionary
        
        // if user is once logged in / register, keep them logged in
        if user != nil {
         
            let id = user!["id"] as? String
            
            if id != nil {
             login()
            }
            
        }
        
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }


}

