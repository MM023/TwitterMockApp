//
//  PostVC.swift
//  TestingApp
//
//  Created by Michael Mitchual on 5/30/17.
//  Copyright © 2017 Michael Mitchual. All rights reserved.
//

import UIKit

class PostVC: UIViewController, UITextViewDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    // declare UI objects
    @IBOutlet weak var textTxt: UITextView!
    @IBOutlet weak var countLbl: UILabel!
    @IBOutlet weak var selectBtn: UIButton!
    @IBOutlet weak var pictureImg: UIImageView!
    @IBOutlet weak var postBtn: UIButton!
    
    // unique id of post
    @objc var uuid = String()
    @objc var imageSelected = false
    
    // first function that is loaded
    override func viewDidLoad() {
        super.viewDidLoad()

        // round corners for the textview and the post button
        textTxt.layer.cornerRadius = textTxt.bounds.width / 50
        postBtn.layer.cornerRadius = postBtn.bounds.width / 20
        
        // declaring colors
        selectBtn.setTitleColor(colorBrandBlue, for: UIControlState())
        postBtn.backgroundColor = colorBrandBlue
        countLbl.textColor = colorSmoothGray
        
        // disable auto scroll layout
        self.automaticallyAdjustsScrollViewInsets = false
        
        // disable button from the begining
        postBtn.isEnabled = false
        postBtn.alpha = 0.4

    }
    
    // entered text in textView
    func textViewDidChange(_ textView: UITextView) {
       
       // number of characters in text view
      let chars = textView.text.characters.count
        
        // white spacing 
        let spacing = NSCharacterSet.whitespacesAndNewlines
        
        countLbl.text = String(140 - chars)
        
        if chars > 140 {
            countLbl.textColor = colorSmoothRed
            postBtn.isEnabled = false
            postBtn.alpha = 0.4
            
            // if entered only spaces and new lines
        } else if textView.text.trimmingCharacters(in: spacing).isEmpty {
            postBtn.isEnabled = false
            postBtn.alpha = 0.4
            
            // everything is correct
        } else {
            countLbl.textColor = colorSmoothGray
            postBtn.isEnabled = true
            postBtn.alpha = 1
        }
        
    }
    
    // touched screen
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        // hide keyboard
        self.view.endEditing(false)
    }
    
    // select picture 
    @IBAction func select_click(_ sender: Any) {
        
        // calling picker for selecting imagw
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        picker.allowsEditing = true
        self.present(picker, animated: true, completion: nil)

    }
    
    // selected image in picker view
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        pictureImg.image = info[UIImagePickerControllerEditedImage] as? UIImage
        self.dismiss(animated: true, completion: nil)
        
        // cast as a true to save image file in server
        if pictureImg.image == info[UIImagePickerControllerEditedImage] as? UIImage {
            imageSelected = true
        }
        
    }
    
        // custom body of HTTP request to upload image file
        @objc func createBodyWithParams(_ parameters: [String: String]?, filePathKey: String?, imageDataKey: Data, boundary: String) -> Data {
            
            let body = NSMutableData();
            
            if parameters != nil {
                for (key, value) in parameters! {
                    body.appendString("--\(boundary)\r\n")
                    body.appendString("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n")
                    body.appendString("\(value)\r\n")
                }
            }
            
            // if file is not selected, it will not upload a file to the server
            var filename = ""
            
            if imageSelected == true {
                filename = "post-\(uuid).jpg"
            }
            
            let mimetype = "image/jpg"
            
            body.appendString("--\(boundary)\r\n")
            body.appendString("Content-Disposition: form-data; name=\"\(filePathKey!)\"; filename=\"\(filename)\"\r\n")
            body.appendString("Content-Type: \(mimetype)\r\n\r\n")
            body.append(imageDataKey)
            body.appendString("\r\n")
            
            body.appendString("--\(boundary)--\r\n")
            
            return body as Data
            
        }

    // function to send request to php to upload the post
    @objc func uploadPost() {
        
        // shortcuts to data to be passed to php file
        let id = user!["id"] as! String
        uuid = UUID().uuidString
        let text = textTxt.text.trunc(140) as String
        
        
        // url path to php file
        let url = NSURL(string: "http://circleapp.pairserver.com/posts.php")!
        let request = NSMutableURLRequest(url: url as URL)
        request.httpMethod = "POST"
        
        // parameters to be passed to php file
        let param = [
            "id" : id,
            "uuid" : uuid,
            "text" : text
        ]
        
        // body
        let boundary = "Boundary-\(UUID().uuidString)"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        // if picture is selected, compress it by 1/2
        var imageData = Data()
        
        if pictureImg.image != nil {
            imageData = UIImageJPEGRepresentation(pictureImg.image!, 0.5)!
        }
        
        // body
        request.httpBody = createBodyWithParams(param, filePathKey: "file", imageDataKey: imageData, boundary: boundary)
        
        // launch session
        URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { (data:Data?, response: URLResponse?, error:Error?) in
            
            
            // get main queu to communicate back to user
            DispatchQueue.main.async(execute: {
                
                
                if error == nil {
                    
                    do {
                        
                        // json containes $returnArray from php file
                        let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                        
                        // declare new variable to store json information
                        guard let parseJSON = json else {
                            print("Error while parsing")
                            return
                        }
                        
                        // get message from $returnArray["message"]
                        let message = parseJSON["message"]
                         
                        // if there is a message - post is made
                        if message != nil {
                            
                            // reset UI
                            self.textTxt.text = ""
                            self.countLbl.text = "140"
                            self.pictureImg.image = nil
                            self.postBtn.isEnabled = false
                            self.postBtn.alpha = 0.4
                            self.imageSelected = false
                            
                            // switch to another scene
                            self.tabBarController?.selectedIndex = 0
                            
                        }

                    } catch {
                        
                        // get main queue to communicate back to user
                        DispatchQueue.main.async(execute: {
                            let message = String(describing: error)
                            appDelegate.infoView(message: message, color: colorSmoothRed)
                        })
                        return
                        
                    }
                    
                } else {
                    
                    // get main queue to communicate back to user
                    DispatchQueue.main.async(execute: {
                        let message = error!.localizedDescription
                        appDelegate.infoView(message: message, color: colorSmoothRed)
                    })
                    return

                }
                
                
            })
            
        }) .resume()
        
    }

    
    
    // post clicked
    @IBAction func post_click(_ sender: Any) {
        
        // if text is entered and it is less than 140 characters
        if !textTxt.text.isEmpty && textTxt.text.characters.count <= 140 {
            
            // call func to upload post
            uploadPost()
            
            
        }
        

    }
   
}


// extension to cut white space from posts
extension String {
    
    // cut / trim our string
    func trunc(_ length: Int, trailing: String? = "...") -> String {
        
        if self.characters.count > length {
            return self.substring(to: self.characters.index(self.startIndex, offsetBy: length)) + (trailing ?? "")
        } else {
            return self
        }
        
    }
    
}
