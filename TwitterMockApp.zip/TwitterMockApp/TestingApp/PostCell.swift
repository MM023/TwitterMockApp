//
//  PostCell.swift
//  TestingApp
//
//  Created by Michael Mitchual on 5/31/17.
//  Copyright © 2017 Michael Mitchual. All rights reserved.
//

import UIKit

class PostCell: UITableViewCell {
    
    // declare UI objects
    @IBOutlet weak var usernameLbl: UILabel!
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var textLbl: UILabel!
    @IBOutlet weak var pictureImg: UIImageView!
    
    
    // first function that is loaded
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // change the username label text color
        usernameLbl.textColor = colorBrandBlue
        
        // round corners of the images that has been included with the post
        pictureImg.layer.cornerRadius = pictureImg.bounds.width / 20
        pictureImg.clipsToBounds = true
    }


}
