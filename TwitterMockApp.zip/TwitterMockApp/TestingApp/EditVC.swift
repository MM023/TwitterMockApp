//
//  EditVC.swift
//  TestingApp
//
//  Created by Michael Mitchual on 6/5/17.
//  Copyright © 2017 Michael Mitchual. All rights reserved.
//

import UIKit

class EditVC: UIViewController, UITextFieldDelegate {

    // declare UI objects
    @IBOutlet weak var usernameTxt: UITextField!
    @IBOutlet weak var nameTxt: UITextField!
    @IBOutlet weak var surnameTxt: UITextField!
    @IBOutlet weak var fullnameLbl: UILabel!
    @IBOutlet weak var emailTxt: UITextField!
    @IBOutlet weak var avaImg: UIImageView!
    @IBOutlet weak var saveBtn: UIButton!
    
    // fist function that is loaded
    override func viewDidLoad() {
        super.viewDidLoad()

        // shortcuts
        let username = user!["username"] as? String
        let fullname = user!["fullname"] as? String
        
        let fullnameArray = fullname!.characters.split {$0 == " "}.map(String.init)
        let firstname = fullnameArray[0]
        let lastname = fullnameArray[1]
        
        let email = user!["email"] as? String
        let ava = user!["ava"] as? String
        
        
        // assign shortcuts to object
        navigationItem.title = "PROFILE"
        usernameTxt.text = username
        nameTxt.text = firstname
        surnameTxt.text = lastname
        emailTxt.text = email
        fullnameLbl.text = "\(nameTxt.text!) \(surnameTxt.text!)"
        
        // get user profile picture
        if ava != "" {
            
            // url path to image
            let imageURL = URL(string: ava!)!
            
            // communicate information back to user as main queue
            DispatchQueue.main.async(execute: {
                
                // get data from image url
                let imageData = try? Data(contentsOf: imageURL)
                
                // if data is not nil assign it to ava.Img
                if imageData != nil {
                    DispatchQueue.main.async(execute: {
                        self.avaImg.image = UIImage(data: imageData!)
                    })
                }
            })
            
        }
        
        // round corners for profile picture
        avaImg.layer.cornerRadius = avaImg.bounds.width / 2
        avaImg.clipsToBounds = true
        saveBtn.layer.cornerRadius = saveBtn.bounds.width / 4.5
        
        // color of save button background
        saveBtn.backgroundColor = colorBrandBlue
        
        // disable button initially
        saveBtn.isEnabled = false
        saveBtn.alpha = 0.4
        
        
        // delegating textFields
        usernameTxt.delegate = self
        nameTxt.delegate = self
        surnameTxt.delegate = self
        emailTxt.delegate = self
        
        // add target to textfield as execution of function
        nameTxt.addTarget(self, action: #selector(EditVC.textFieldDidChange(_:)), for: .editingChanged)
        surnameTxt.addTarget(self, action: #selector(EditVC.textFieldDidChange(_:)), for: .editingChanged)
        usernameTxt.addTarget(self, action: #selector(EditVC.textFieldDidChange(_:)), for: .editingChanged)
        emailTxt.addTarget(self, action: #selector(EditVC.textFieldDidChange(_:)), for: .editingChanged)
    }
    
    
    // once values have been entered in the textfield
    @objc func textFieldDidChange(_ textField : UITextView) {
        fullnameLbl.text = "\(nameTxt.text!) \(surnameTxt.text!)"
        
        // if textfields are empty, disable save button
        if usernameTxt.text!.isEmpty || nameTxt.text!.isEmpty || surnameTxt.text!.isEmpty || emailTxt.text!.isEmpty {
            
            saveBtn.isEnabled = false
            saveBtn.alpha = 0.4
            
        // enable button if text has been entered
        } else {
            
            saveBtn.isEnabled = true
            saveBtn.alpha = 1
            
        }
    }
    
    // function for when the save button has been clicked
    @IBAction func save_clicked(_ sender: Any) {
        
        // if no text has been entered
        if usernameTxt.text!.isEmpty || emailTxt.text!.isEmpty || nameTxt.text!.isEmpty || surnameTxt.text!.isEmpty {
            
            //red placeholders
            usernameTxt.attributedPlaceholder = NSAttributedString(string: "username", attributes: [NSAttributedStringKey.foregroundColor: colorSmoothRed])
            emailTxt.attributedPlaceholder = NSAttributedString(string: "email", attributes: [NSAttributedStringKey.foregroundColor: UIColor.red])
            nameTxt.attributedPlaceholder = NSAttributedString(string: "name", attributes: [NSAttributedStringKey.foregroundColor: colorSmoothRed])
            surnameTxt.attributedPlaceholder = NSAttributedString(string: "surname", attributes: [NSAttributedStringKey.foregroundColor: colorSmoothRed])
            
        // if text has been entered
        } else {
            
            // remove keyboard
            self.view.endEditing(true)
            
            // shortcuts
            let username = usernameTxt.text!.lowercased()
            let fullname = fullnameLbl.text!
            let email = emailTxt.text!.lowercased()
            let id = user!["id"]!
            
            // preparing request to best
            let url = URL(string: "http://circleapp.pairserver.com/updateUser.php")!
            let request = NSMutableURLRequest(url: url)
            request.httpMethod = "POST"
            let body = "username=\(username)&fullname=\(fullname)&email=\(email)&id=\(id)"
            request.httpBody = body.data(using: String.Encoding.utf8)
            
            // launch session
            URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { (data:Data?, response: URLResponse?, error:Error?) in
                
                // no error
                if error == nil {
                    
                    // get main queue to communicate back to user
                    DispatchQueue.main.async(execute: {
                        
                        do {
                            // declare json var to store $returnArray from php file
                            let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                            
                            // assign json to new secure var, prevent from crashes
                            guard let parseJSON = json else {
                                print("Error while parsing")
                                return
                            }
                            
                            // get if from parseJSON dictionary
                            let id = parseJSON["id"]
                            
                            
                            // successfully updated
                            if id != nil {
                                
                                // save user information we received from our host
                                UserDefaults.standard.set(parseJSON, forKey: "parseJSON")
                                user = UserDefaults.standard.value(forKey: "parseJSON") as? NSDictionary
                                
                                // go to tabbar / home page
                                DispatchQueue.main.async(execute: {
                                    appDelegate.login()
                                })
                                
                            }
                            
                            
                            // error while jsoning
                        } catch {
                            print("Caught an error: \(error)")
                        }
                        
                    })
                    
                    
                    // error with php request
                } else {
                    print("Error: \(String(describing: error))")
                }
                
            }).resume()
            
            
        }
    }

}
    
    




