//
//  ResetVC.swift
//  TestingApp
//
//  Created by Michael Mitchual on 5/25/17.
//  Copyright © 2017 Michael Mitchual. All rights reserved.
//

import UIKit

class ResetVC: UIViewController {
    
    // declare UI object
    @IBOutlet weak var emailTxt: UITextField!
    
    // first function that is loaded
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // reset button clicked
    @IBAction func reset_click(_ sender: Any) {
    
        // if the email textfield is empty...
        if emailTxt.text!.isEmpty {
            
            // show red place holders
            emailTxt.attributedPlaceholder = NSAttributedString(string: "Email", attributes: [NSAttributedStringKey.foregroundColor: UIColor.red])
        
        } else {
            
            // remove keyboard
            self.view.endEditing(true)
            
            let url = NSURL(string: "http://circleapp.pairserver.com/resetPassword.php")!
            let request = NSMutableURLRequest(url: url as URL)
            request.httpMethod = "POST"
            print("Request: \(request)")
            
            // body for the request
            let body = "email=\(emailTxt.text!)"
            
            request.httpBody = body.data(using: String.Encoding.utf8)
            
            print("Request: \(request)")
            
            print("RequestBody: \(String(describing: request.httpBody))")
            
            
            URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { (data:Data?, response: URLResponse?, error:Error?) in
                
                print(1)
                
                if (error == nil) {
                    
                    // communicate back to UI
                    DispatchQueue.main.async(execute: {
                        
                        do {
                            
                            let json  = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                            
                                print(1)
                            
                            guard let parseJSON = json else {
                                print ("Error while parsing JSON")
                                return
                            }
                            
                            let email = parseJSON["email"]
                            
                            // password successfully reset
                            if email != nil {
                                // get main queue to communicate back to user
                                DispatchQueue.main.async(execute: {
                                    let message = parseJSON["message"] as! String
                                    appDelegate.infoView(message: message, color: colorLightGreen)
                                })

                            } else {
                                
                                // get main queue to communicate back to user
                                DispatchQueue.main.async(execute: {
                                    let message = parseJSON["message"] as! String
                                    appDelegate.infoView(message: message, color: colorSmoothRed)
                                })

                            }
                            
                        } catch {
                            DispatchQueue.main.async(execute: {
                                let message = error as! String
                                appDelegate.infoView(message: message, color: colorSmoothRed)
                            })

                        }
                        
                    })
                    
                } else {
                    
                    // get main queue to communicate back to user
                    DispatchQueue.main.async(execute: {
                        let message = error!.localizedDescription
                        appDelegate.infoView(message: message, color: colorSmoothRed)
                    })

                }
                
            // launch prepared session
            }).resume()
            
        }
    }
    
    // white status bar
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return UIStatusBarStyle.lightContent
    }
    
    // touched screen
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        // hide keyboard
        self.view.endEditing(false)
    }



}
