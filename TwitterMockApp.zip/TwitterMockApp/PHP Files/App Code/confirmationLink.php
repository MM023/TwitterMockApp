<?php 

// get information passed to this file
$token = htmlentities($_GET["token"]); 

if (empty($_GET["token"])) {
    echo 'Missing required information';
    return;
} 

// build connection
$file = parse_ini_file("circle.ini"); 

// store information from ini file in variable
$host = trim($file["dbhost"]);
$user = trim($file["dbuser"]);
$pass = trim($file["dbpass"]);
$name = trim($file["dbname"]);  

// include access.php to call functions from this file
require ("access.php");
$access = new access($host, $user, $pass, $name);
$access->connect(); 


// get the id of the user
$id = $access->getUserID("emailTokens", $token);

if (empty($id["id"])) {
    echo 'User with this token is not found';
    return;
} 


// change status of confirmation and delete token
// assign result of function executed to $result variable
$result = $access->emailConfirmationStatus(1, $id["id"]);

if ($result) {
    
    // delete token from 'emailTokens' table of the database
    $access->deleteToken("emailTokens", $token);
    echo 'Thank You! Your email is now confirmed';
    
}

// close connection
$access->disconnect();


?>