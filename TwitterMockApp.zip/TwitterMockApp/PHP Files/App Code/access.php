<?php 

// declare class to access this php file
class access { 

    // global variable connections
	var $host = null;
    var $user = null;
    var $pass = null;
    var $name = null;
    var $conn = null;
    var $result = null;  

    // function for constructing class
    function __construct($dbhost, $dbuser, $dbpass, $dbname) { 

    	$this->host = $dbhost;
        $this->user = $dbuser;
        $this->pass = $dbpass;
        $this->name = $dbname;


    } 

    // connection function
    public function connect() {

    // establish connection and store it in $conn variable
    $this->conn = new mysqli($this->host, $this->user, $this->pass, $this->name); 

    // if there is an error...
     if (mysqli_connect_errno()) {
            echo 'Could not connect to database';
        } 

        // support all languages
        $this->conn->set_charset("utf8");

    } 

     // disconnection function
    public function disconnect() {

        if ($this->conn != null) {
            $this->conn->close();
        }

    } 

    // function to register user    
     public function registerUser($username, $password, $salt, $email, $fullname) {

        // sql command
        $sql = "INSERT INTO users SET username=?, password=?, salt=?, email=?, fullname=?";

        // store query result in $statement variable
        $statement = $this->conn->prepare($sql);

        // if there is an error...
        if (!$statement) {
            throw new Exception($statement->error);
        }

        // bind 5 parameters of type string to be placed in $sql command
        $statement->bind_param("sssss", $username, $password, $salt, $email, $fullname);

        $returnValue = $statement->execute(); 

        // statement result
        return $returnValue;

    } 

     // function to select the user information
     public function selectUser($username) {

        // declare array to store selected information
        $returnArray = array();

        // sql command
        $sql = "SELECT * FROM users WHERE username='".$username."'";

        // assign result from $sql variable to $result variable
        $result = $this->conn->query($sql);

        // if at least one result is returned returned
        if ($result != null && (mysqli_num_rows($result) >= 1 )) {

            // assign results to $row variable as an associative array
            $row = $result->fetch_array(MYSQLI_ASSOC);

            if (!empty($row)) {
                $returnArray = $row;
            }

        }

        // statement result
        return $returnArray;

    } 

     // function to save email confirmation messagess token
    public function saveToken($table, $id, $token) {

        // sql command
        $sql = "INSERT INTO $table SET id=?, token=?";

        // prepare statement to be executed
        $statement = $this->conn->prepare($sql);

        // if there is an error...
        if (!$statement) {
            throw new Exception($statement->error);
        }

        // bind parameters to sql statement
        $statement->bind_param("is", $id, $token);

        // launch / execute and store feedback in $returnValue
        $returnValue = $statement->execute(); 


        // statement result
        return $returnValue;




    } 

	// function to get ID of user via $emailToken that they received via email
    function getUserID($table, $token) {

        // declare array to store selected information
        $returnArray = array();

        // sql command
        $sql = "SELECT id FROM $table WHERE token = '".$token."'";

        // launch sql statement
        $result = $this->conn->query($sql);

        // if $result variableis not empty and stores content
        if ($result != null && (mysqli_num_rows($result) >= 1)) {

            // content from $result variable convert to associative array and store in $row variable
            $row = $result->fetch_array(MYSQLI_ASSOC);

            if (!empty($row)) {
                $returnArray = $row;
            }
        }

        // statement result
        return $returnArray;

    } 

    // function to change status of emailConfirmation column
    function emailConfirmationStatus($status, $id) {

        // sql command
        $sql = "UPDATE users SET emailConfirmed=? WHERE id=?";  

        // prepare statement to be executed
        $statement = $this->conn->prepare($sql);

        // if there is an error...
        if (!$statement) {
            throw new Exception($statement->error);
        }

        // bind paramateres to sql statement
        $statement->bind_param("ii", $status, $id);

        // launch / execute and store feedback in $returnValue
        $returnValue = $statement->execute();

        // statement result
        return $returnValue;

    } 

    // function to delete token once email is confirmed
    function deleteToken($table, $token) {

        // sql command
        $sql = "DELETE FROM $table WHERE token=?"; 

        // prepare statement to be executed
        $statement = $this->conn->prepare($sql);

        // if there is an error...
        if (!$statement) {
            throw new Exception($statement->error);
        }

        // bind parameters to sql statement
        $statement->bind_param("s", $token);

        // launch / execute and store feedback in $returnValue
        $returnValue = $statement->execute();

        // statement result
        return $returnValue;

    } 

    // function to get all user information
    public function getUser($username) {

        // declare array to store all information
        $returnArray = array();

        // sql command
        $sql = "SELECT * FROM users WHERE username='".$username."'";

        // execute / query $sql statement
        $result = $this->conn->query($sql);

        // if a result is returned...
        if ($result != null && (mysqli_num_rows($result) >= 1)) {

            // assign result to $row variable as associative array
            $row = $result->fetch_array(MYSQLI_ASSOC);

            // if content is assigned to $row variable, assign content to $returnArray variable
            if (!empty($row)) {
                $returnArray = $row;
            }
        }

        // statement result
        return $returnArray;

    } 

    // function to select user information with email
    public function selectUserViaEmail($email) {

        // declare array to store selected information
        $returnArray = array();

        // sql command
        $sql = "SELECT * FROM users WHERE email='".$email."'";

        // assign result from $sql variable to $result variable
        $result = $this->conn->query($sql);

        // if at least 1 result is returned...
        if ($result != null && (mysqli_num_rows($result) >= 1 )) {

            // assign results from $row variable as associative array
            $row = $result->fetch_array(MYSQLI_ASSOC);

            if (!empty($row)) {
                $returnArray = $row;
            }

        }

        // statement result
        return $returnArray;

    } 

     // function to update password
     public function updatePassword($id, $password, $salt) {

        // sql command
        $sql = "UPDATE users SET password=?, salt=? WHERE id=?"; 

        // sql statement
        $statement = $this->conn->prepare($sql);

        // if there is an error...
        if (!$statement) {
            throw new Exception($statement->error);
        }

        // bind parameters to sql statement
        $statement->bind_param("ssi", $password, $salt, $id);

        $returnValue = $statement->execute(); 

        // statement result
        return $returnValue;

    } 

    // function to save avatar path in database
    function updateAvaPath($path, $id) {

        // sql statement
        $sql = "UPDATE users SET ava=? WHERE id=?";

        // prepare to be executed
        $statement = $this->conn->prepare($sql);

        // if there is an error...
        if (!$statement) {
            throw new Exception($statement->error);
        }

        // bind parameters to sql statement
        $statement->bind_param("si", $path, $id);

        // assign execution result to $returnValue variable
        $returnValue = $statement->execute();

        // statement result
        return $returnValue;

    }

    // function to select user information with id
    public function selectUserViaID($id) {

        // declare array to store selected information
        $returArray = array();

        // sql command
        $sql = "SELECT * FROM users WHERE id='".$id."'";

        // assign result from $sql variable to $result var
        $result = $this->conn->query($sql);

        // if at least 1 result returned....
        if ($result != null && (mysqli_num_rows($result) >= 1 )) {

            /// assign results from $row variable as associative array
            $row = $result->fetch_array(MYSQLI_ASSOC);

            if (!empty($row)) {
                $returArray = $row;
            }

        }

        // statement result
        return $returArray;

    } 

    // function to insert post in database
    public function insertPost($id, $uuid, $text, $path) {
        
        // sql statement
        $sql = "INSERT INTO posts SET id=?, uuid=?, text=?, path=?";
        
        // prepare sql to be executed
        $statement = $this->conn->prepare($sql);

        // if there is an error...
        if (!$statement) {
            throw new Exception($statement->error);
        }

        // bind parameters to sql statement
        $statement->bind_param("isss", $id, $uuid, $text, $path);

        // execute statement and assign result of execution to $returnValue
        $returnValue = $statement->execute();

        // statement result
        return $returnValue;

    } 

    // function to select all posts & user information made by user with relevant $id
    public function selectPosts($id) {

        // declare array to store selected information
        $returnArray = array();

        // sql JOIN statement
        $sql = "SELECT posts.id,
        posts.uuid,
        posts.text,
        posts.path,
        posts.date,
        users.id,
        users.username,
        users.fullname,
        users.email,
        users.ava
        FROM circleapp_Circle2.posts JOIN circleapp_Circle2.users ON
        posts.id = $id AND users.id = $id ORDER by date DESC";

        // prepare sql statement to be executed
        $statement = $this->conn->prepare($sql);

        // if there is an error...
        if (!$statement) {
            throw new Exception($statement->error);
        }

        // execute sql statement
        $statement->execute();

        // results returned from the execution
        $result = $statement->get_result();

        // every time when a result is returned, convert $result variable to associative array append to $row variable
        while ($row = $result->fetch_assoc()) {
            $returnArray[] = $row;
        }

        return $returnArray;

    } 

    // function to delete post according to passed uui
    public function deletePost($uuid) {

        // sql statement to be executed
        $sql = "DELETE FROM posts WHERE uuid = ?";

        // prepare statement to be executed as soon as parameters are binded in place of '?'
        $statement = $this->conn->prepare($sql);

        // if there is an error...
        if (!$statement) {
            throw new Exception($statement->error);
        }

        // bind parameters to sql statement
        $statement->bind_param("s", $uuid); 

        // execute statement
        $statement->execute();

        // assign number of affected rows to $returnValue, to see if post is deleted or not
        $returnValue = $statement->affected_rows;

        // statement result
        return $returnValue;

    } 

    // function to search / select user
    public function selectUsers($word, $username) {

        // variable to store all returned inf from db
        $returnArray = array();

        // sql statement to be executed if nothing is entered
        $sql = "SELECT id, username, email, fullname, ava FROM users WHERE NOT username = '".$username."'";

        // if word is entered, alter sql statement for wider search
        if (!empty($word)) {
            $sql .= " AND ( username LIKE ? OR fullname LIKE ? )";
        }

        // prepare to be executed as soon as variable is binded
        $statement = $this->conn->prepare($sql);

        // if there is an error...
        if (!$statement) {
            throw new Exception($statement->error);
        }

        // if word is entered, bind parameter
        if (!empty($word)) {
            $word = '%' . $word . '%'; // %bob%
            $statement->bind_param("ss", $word, $word);
        }

        // execute statement
        $statement->execute();

        // assign returned results to $result var
        $result = $statement->get_result();

        // every time a result is returned, convert $result variable to associative array append to $row variable
        while ($row = $result->fetch_assoc()) {

            // store all $rows results in $returnArray variable
            $returnArray[] = $row;
        }

        // result variable feedback
        return $returnArray;

    }

    // function to update user in database via $id variable
    public function updateUser($username, $fullname, $email, $id) {

        // sql statement
        $sql = "UPDATE users SET username=?, fullname=?, email=? WHERE id=?";

        // prepare statement to be executed as soon as parameters are binded in place of '?'
        $statement = $this->conn->prepare($sql);

        // if there is an error...
        if (!$statement) {
            throw new Exception($statement->error);
        }

        // bind parameters to sql statement
        $statement->bind_param("sssi", $username, $fullname, $email, $id);

        // assign execution result to $returnValue
        $returnValue = $statement->execute();
        
        // statement result
        return $returnValue;

    }


}


?>