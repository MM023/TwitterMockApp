<?php


echo $_GET["message"];


?>