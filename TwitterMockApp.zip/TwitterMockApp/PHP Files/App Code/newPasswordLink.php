<?php


// check passed information
if (!empty($_POST["password_1"]) && !empty($_POST["password_2"]) && !empty($_POST["token"])) {

    $password_1 = htmlentities($_POST["password_1"]);
    $password_2 = htmlentities($_POST["password_2"]);
    $token = htmlentities($_POST["token"]);


      // build connection
      $file = parse_ini_file("circle.ini"); 

      // store information from ini file in variable
      $host = trim($file["dbhost"]);
      $user = trim($file["dbuser"]);
      $pass = trim($file["dbpass"]);
      $name = trim($file["dbname"]);  

      // include access.php to call functions from this file
      require ("access.php");
      $access = new access($host, $user, $pass, $name);
      $access->connect(); 

        // get user id via user token that passed to this file
        $user = $access->getUserID("passwordTokens", $token);


        // update the database
        if (!empty($user)) {

            // generate secured password
            $salt = openssl_random_pseudo_bytes(20);
            $secured_password = sha1($password_1 . $salt);
            
            // update user password
            $result = $access->updatePassword($user["id"], $secured_password, $salt);

            if ($result) {

                // delete unique token
                $access->deleteToken("passwordTokens", $token);
                $message = "Successfully created new password";

                header("Location:didResetPassword.php?message=" . $message);

            } else {
                echo 'User ID is empty';
            }


        }

    } else {
        $message = "Passwords do not match";
    }

}

?>



<!--FIRST LOAD-->
    <html>
           <head>
               <!--Title-->
               <title>Create new password</title>

               <!--CSS Style-->
               <style>

                   .password_field
                   {
                       margin: 10px;
                   }

                   .button
                   {
                       margin: 10px;
                   }

               </style>

           </head>


            <body>
                <h1>Create new password</h1>

                <?php
                    if (!empty($message)) {
                        echo "</br>" . $message . "</br>";
                    }
                ?>

            <!--Forms-->
            <form method="POST" action="<?php $_SERVER['PHP_SELF'];?>">
            <div><input type="password" name="password_1" placeholder="New password:" class="password_field"/></div>
            <div><input type="password" name="password_2" placeholder="Repeat password:" class="password_field"/></div>
            <div><input type="submit" value="Save" class="button"/></div>
            <input type="hidden" value="<?php echo $_GET['token'];?>" name="token">
            </form>

            </body>

    </html>

