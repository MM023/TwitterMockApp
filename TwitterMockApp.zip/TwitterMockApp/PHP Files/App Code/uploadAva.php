<?php 


// get information passed to this file
if (empty($_REQUEST["id"])) {
    $returnArray["message"] = "Missing required information";
    return;
}

// store value passed in a variable
$id = htmlentities($_REQUEST["id"]); 

// create a folder for user with the value of his/her ID
$folder = "ava/" . $id; 

// if it doesn't exist, create the folder
if (!file_exists($folder)) {
    mkdir($folder, 0777, true); 
	
}

// move the uploaded file
$folder = $folder . "/" . basename($_FILES["file"]["name"]);

if (move_uploaded_file($_FILES["file"]["tmp_name"], $folder)) {
    $returnArray["status"] = "200";
    $returnArray["message"] = "The file has been uploaded";
} else {
    $returnArray["status"] = "300";
    $returnArray["message"] = "Error while uploading";
}

// build connection
$file = parse_ini_file("circle.ini"); 

// store information from ini file in variable
$host = trim($file["dbhost"]);
$user = trim($file["dbuser"]);
$pass = trim($file["dbpass"]);
$name = trim($file["dbname"]);  

// include access.php to call functions from this file
require ("access.php");
$access = new access($host, $user, $pass, $name);
$access->connect(); 

// save path to upload file in database
$path =  "http://circleapp.pairserver.com/ava/" . $id . "/ava.jpg";
$access->updateAvaPath($path, $id);

// get new user information after updating ava
$user = $access->selectUserViaID($id);

$returnArray["id"] = $user["id"];
$returnArray["username"] = $user["username"];
$returnArray["fullname"] = $user["fullname"];
$returnArray["email"] = $user["email"];
$returnArray["ava"] = $user["ava"];


// close connection
$access->disconnect();


// send information back to user via json
echo json_encode($returnArray);


?>
