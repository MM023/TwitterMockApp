<?php 

// get information passed to this file
$username = htmlentities($_REQUEST["username"]);
$password = htmlentities($_REQUEST["password"]);
$email = htmlentities($_REQUEST["email"]);
$fullname = htmlentities($_REQUEST["fullname"]); 

// if the information is empty...
if (empty($_REQUEST["username"]) || empty($_REQUEST["password"]) || empty($_REQUEST["email"]) || empty($_REQUEST["fullname"])) {
    $returnArray["status"] = "400";
    $returnArray["message"] = "Missing required information";
    echo json_encode($returnArray);
    return;
} 

// create a secured passowrd
$salt = openssl_random_pseudo_bytes(20);
$secured_password = sha1($password . $salt);

// build connection
$file = parse_ini_file("circle.ini"); 

// store information from ini file in variable
$host = trim($file["dbhost"]);
$user = trim($file["dbuser"]);
$pass = trim($file["dbpass"]);
$name = trim($file["dbname"]);  

require ("access.php");
$access = new access($host, $user, $pass, $name);
$access->connect(); 


// insert user information
$result = $access->registerUser($username, $secured_password, $salt, $email, $fullname);

// if registration is successful...
if ($result) { 

	$user = $access->selectUser($username); 

	$returnArray["status"] = "200";
    $returnArray["message"] = "Successfully registered";
    $returnArray["id"] = $user["id"];
    $returnArray["username"] = $user["username"];
    $returnArray["email"] = $user["email"];
    $returnArray["fullname"] = $user["fullname"];
    $returnArray["ava"] = $user["ava"]; 

    // include email.php
    require ("email.php");

    // store information in new email variable
    $email = new email();

    // store generated token in $token variable
    $token = $email->generateToken(20);

    // save information in 'emailTokens' table in database
    $access->saveToken("emailTokens", $user["id"], $token);

    // refer to emailing information
    $details = array();
    $details["subject"] = "Email confirmation on Circle";
    $details["to"] = $user["email"];
    $details["fromName"] = "Circle";
    $details["fromEmail"] = "circle@app.pairsite.com";

    // access template file
    $template = $email->confirmationTemplate();

    // replace {token} from confirmationTemplate.html by $token variable and store all content in $template variable
    $template = str_replace("{token}", $token, $template);

    $details["body"] = $template;

    $email->sendEmail($details);
    
    } else { 

    echo mysqli_errno();
    $returnArray["status"] = "400";
    $returnArray["message"] = "Could not register with provided information";
} 

// close connection
$access->disconnect(); 

// send data to user via json
echo json_encode($returnArray); 

?>