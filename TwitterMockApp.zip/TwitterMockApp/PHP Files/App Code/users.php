<?php

// build connection
$file = parse_ini_file("circle.ini"); 

// store information from ini file in variable
$host = trim($file["dbhost"]);
$user = trim($file["dbuser"]);
$pass = trim($file["dbpass"]);
$name = trim($file["dbname"]);

// include access.php to call functions from this file
require ("access.php");
$access = new access($host, $user, $pass, $name);
$access->connect();   // launch opend connection function


// check data passed to this file from out app
$word = null;
$username = htmlentities($_REQUEST["username"]);

if (!empty($_REQUEST["word"])) {
    $word = htmlentities($_REQUEST["word"]);
}


// access searching function and retrieve data from server
$users = $access->selectUsers($word, $username);

if (!empty($users)) {
    $returnArray["users"] = $users;
} else {
    $returnArray["message"] = 'Could not find records';
}


// close connection
$access->disconnect();


// pass information back to user via json
echo json_encode($returnArray);



?>



