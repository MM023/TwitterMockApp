<?php 

// get information passed to this file
if (empty($_REQUEST["username"]) && empty($_REQUEST["fullname"]) && empty($_REQUEST["email"]) && empty($_REQUEST["id"])) {
    $returnArray["status"] = "400";
    $returnArray["message"] = "Missing required information";
    return;
}

// crypting html variables that were passed to this file
$username = htmlentities($_REQUEST["username"]);
$fullname = htmlentities($_REQUEST["fullname"]);
$email = htmlentities($_REQUEST["email"]);
$id = htmlentities($_REQUEST["id"]);


// build connection
$file = parse_ini_file("circle.ini"); 

// store information from ini file in variable
$host = trim($file["dbhost"]);
$user = trim($file["dbuser"]);
$pass = trim($file["dbpass"]);
$name = trim($file["dbname"]);  

// include access.php to call functions from this file
require ("access.php");
$access = new access($host, $user, $pass, $name);
$access->connect(); $host, $user, $pass, $name);
$access->connect(); 

// update user information
$result = $access->updateUser($username, $fullname, $email, $id);

if (!empty($result)) {

    // get newly update user information
    $user = $access->selectUserViaID($id);

    $returnArray["id"] = $user["id"];
    $returnArray["username"] = $user["username"];
    $returnArray["fullname"] = $user["fullname"];
    $returnArray["email"] = $user["email"];
    $returnArray["ava"] = $user["ava"];
    $returnArray["status"] = "200";
    $returnArray["message"] = "Successfully updated";


} else {
    $returnArray["status"] = "400";
    $returnArray["message"] = "Could not update user";
}


// close connection
$access->disconnect();


// return information back to user via json
echo json_encode($returnArray);


?>