<?php 

// build connection
$file = parse_ini_file("circle.ini"); 

// store information from ini file in variable
$host = trim($file["dbhost"]);
$user = trim($file["dbuser"]);
$pass = trim($file["dbpass"]);
$name = trim($file["dbname"]); 

// include access.php to call functions from this file
require ("access.php");
$access = new access($host, $user, $pass, $name);
$access->connect(); 


// check if data was passed to this file. if so, save the post
if (!empty($_REQUEST["uuid"]) && !empty($_REQUEST["text"])) {

	// pass post from html file and assign to variables
    $id = htmlentities($_REQUEST["id"]);
    $uuid = htmlentities($_REQUEST["uuid"]);
    $text = htmlentities($_REQUEST["text"]); 

    // create a folder in our server to store pictures
  	$folder = "posts/" . $id; 

    // if no posts exists, create it
    if (!file_exists($folder)) {
        mkdir($folder, 0777, true);
    } 

    // move the updloaded file
    $folder = $folder . "/" . basename($_FILES["file"]["name"]);

    if (move_uploaded_file($_FILES["file"]["tmp_name"], $folder)) {
        $returnArray["message"] = "Post has been made with a picture";
        $path = "http://circleapp.pairserver.com/posts/" . $id . "/post-" . $uuid . ".jpg";
    } else {
        $returnArray["message"] = "Post has been made without a picture";
        $path = "";
    } 

     // save path and other post details in the database
    $access->insertPost($id, $uuid, $text, $path); 

    } else if (!empty($_REQUEST["uuid"]) && empty($_REQUEST["id"])) {


    // get uuid of post and path to post picture passed to this php file via swift POST
    $uuid = htmlentities($_REQUEST["uuid"]);
    $path = htmlentities($_REQUEST["path"]);

    // delete post according to uuid
    $result = $access->deletePost($uuid);

    if (!empty($result)) {
        $returnArray["message"] = "Successfully deleted";
        $returnArray["result"] = $result;


        // delete file according to its path if it exists
        if (!empty($path)) {

            $path = str_replace("http://circleapp.pairserver.com", $path);

            // file deleted successfully
            if (unlink($path)) {
                $returnArray["status"] = "1000";

            // could not delete file
            } else {
                $returnArray["status"] = "400";
            }
        }


	} else {

        $returnArray["message"] = "Could not delete post";
    }


} else {

    $id = htmlentities($_REQUEST["id"]);


    // select post of user related to the ID
    $posts = $access->selectPosts($id);

    // if posts are found, append them to $returnArray variable
    if (!empty($posts)) {
        $returnArray["posts"] = $posts;
    }


}



	// close connection
	$access->disconnect();


	// send information back to user via json
	echo json_encode($returnArray);


?>