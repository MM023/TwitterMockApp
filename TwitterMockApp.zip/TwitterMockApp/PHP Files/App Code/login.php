<?php 

// get information passed to this file
if ( empty($_REQUEST["username"]) || empty($_REQUEST["password"])) {

    $returnArray["status"] = "400";
    $returnArray["message"] = "Missing required information"; 
    return;

} 

// assignment passed information to a variable
$username = htmlentities($_REQUEST["username"]);
$password = htmlentities($_REQUEST["password"]);

// build connection
$file = parse_ini_file("circle.ini"); 

// store information from ini file in variable
$host = trim($file["dbhost"]);
$user = trim($file["dbuser"]);
$pass = trim($file["dbpass"]);
$name = trim($file["dbname"]);  

// include access.php to call functions from this file
require ("access.php");
$access = new access($host, $user, $pass, $name);
$access->connect(); 


// get the user
$user = $access->getUser($username);

if (empty($user)) {

    $returnArray["status"] = "403";
    $returnArray["message"] = "User is not found";
    echo json_encode($returnArray);
    return;

} 

// check the validity of passed user informtaion
// get password and salt from database
$secure_password = $user["password"];
$salt = $user["salt"];


// check to see if the passwords match
if ($secure_password == sha1($password . $salt)) {

    $returnArray["status"] = "200";
    $returnArray["message"] = "Logged in successfully";
    $returnArray["id"] = $user["id"];
    $returnArray["username"] = $user["username"];
    $returnArray["email"] = $user["email"];
    $returnArray["fullname"] = $user["fullname"];
    $returnArray["ava"] = $user["ava"];
    echo json_encode($returnArray);
    return;

} else {

    $returnArray["status"] = "403";
    $returnArray["message"] = "Password do not match";
    echo json_encode($returnArray);
    return;

}


// close the connection
$access->disconnect();



// pass the information back to the user via json
echo json_encode($returnArray);




?>