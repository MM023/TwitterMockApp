<?php 

// get information passed to this file
if (empty($_REQUEST["email"])) {
    $returnArray["message"] = "Missing required information";
    echo json_encode($returnArray);
    return;
}

// store information in email variable
$email = htmlentities($_REQUEST["email"]);  

// build connection
$file = parse_ini_file("circle.ini"); 

// store information from ini file in variable
$host = trim($file["dbhost"]);
$user = trim($file["dbuser"]);
$pass = trim($file["dbpass"]);
$name = trim($file["dbname"]);  

// include access.php to call functions from this file
require ("access.php");
$access = new access($host, $user, $pass, $name);
$access->connect(); 

// check if email is found in the database as a registered email address
// store results in $user variable
$user = $access->selectUserViaEmail($email);


// if the $user variable is empty...
if (empty($user)) {
    $returnArray["message"] = "Email not found";
    echo json_encode($returnArray);
    return;
}

// include email.php
require ("email.php"); 

// create an email
$email = new email();

// generate unique string token associated with user in the database.
$token = $email->generateToken(20);

// store unique token in our database
$access->saveToken("passwordTokens", $user["id"], $token);

// prepare email message
$details = array();
$details["subject"] = "Password reset request on Circle";
$details["to"] = $user["email"];
$details["fromName"] = "Circle";
$details["fromEmail"] = "circle@app.pairsite.com";

// load html template
$template = $email->resetPasswordTemplate();
$template = str_replace("{token}", $token, $template);
$details["body"] = $template;

// send email to user
$email->sendEmail($details);


// return message to our app
$returnArray["email"] = $user["email"];
$returnArray["message"] = "We have sent you email to reset password";
echo json_encode($returnArray);


// close connection
$access->disconnect();

?>